package school.sptech;

public class Main {
    public static void main(String[] args) {
        ExercicioMetodos exercicioMetodos = new ExercicioMetodos();
        exercicioMetodos.maiorNumero(4, 6, 8);
    }
}
